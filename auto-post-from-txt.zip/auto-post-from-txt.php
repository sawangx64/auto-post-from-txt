<?php
/*
Plugin Name: Auto Post From TXT
Description: Plugin untuk membuat postingan otomatis dari setiap baris file .txt dengan opsi untuk dijadwalkan atau disimpan sebagai draf, mengisi konten postingan dengan gambar, dan mengatur kategori serta tag.
Version: 1.7
Author: Nama Anda
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

function apft_admin_menu() {
    add_menu_page(
        'Auto Post From TXT',
        'Auto Post From TXT',
        'manage_options',
        'auto-post-from-txt',
        'apft_admin_page',
        'dashicons-upload',
        6
    );
}
add_action('admin_menu', 'apft_admin_menu');

function apft_admin_page() {
    $categories = get_categories(array('hide_empty' => false));
    ?>
    <div class="wrap">
        <h1>Auto Post From TXT</h1>
        <form method="post" enctype="multipart/form-data">
            <input type="file" name="apft_file" accept=".txt" />
            <p>
                <label for="apft_post_status">Status Post:</label>
                <select name="apft_post_status" id="apft_post_status">
                    <option value="publish">Publish</option>
                    <option value="draft">Draft</option>
                    <option value="future">Scheduled</option>
                </select>
            </p>
            <p id="schedule-options-container" style="display: none;">
                <label for="apft_schedule_type">Tipe Penjadwalan:</label>
                <select name="apft_schedule_type" id="apft_schedule_type">
                    <option value="">-- Pilih Tipe --</option>
                    <option value="minute">Menit</option>
                    <option value="hour">Jam</option>
                    <option value="day">Hari</option>
                </select>
                <br />
                <label for="apft_schedule_interval">Interval Penjadwalan:</label>
                <input type="number" name="apft_schedule_interval" id="apft_schedule_interval" min="1" />
                <span id="apft_schedule_interval_unit"></span>
            </p>
            <p id="schedule-date-container" style="display: none;">
                <label for="apft_schedule_date">Tanggal dan Waktu Mulai:</label>
                <input type="datetime-local" name="apft_schedule_date" id="apft_schedule_date" />
            </p>
            <p>
                <label for="apft_category">Pilih Kategori yang Ada atau Masukkan Kategori Baru:</label>
                <select name="apft_category_select" id="apft_category_select">
                    <option value="">-- Pilih Kategori --</option>
                    <?php foreach ($categories as $category) : ?>
                        <option value="<?php echo esc_attr($category->term_id); ?>"><?php echo esc_html($category->name); ?></option>
                    <?php endforeach; ?>
                </select>
                <br />
                <label for="apft_category_input">Atau Masukkan Kategori Baru (pisahkan dengan koma):</label>
                <input type="text" name="apft_category_input" id="apft_category_input" />
            </p>
            <input type="submit" name="apft_upload" class="button-primary" value="Upload and Post" />
        </form>
        <?php
        if (isset($_POST['apft_upload']) && !empty($_FILES['apft_file']['tmp_name'])) {
            $post_status = sanitize_text_field($_POST['apft_post_status']);
            $schedule_date = !empty($_POST['apft_schedule_date']) ? sanitize_text_field($_POST['apft_schedule_date']) : '';
            $schedule_type = sanitize_text_field($_POST['apft_schedule_type']);
            $schedule_interval = intval($_POST['apft_schedule_interval']);
            $selected_category_id = intval($_POST['apft_category_select']);
            $new_categories_input = sanitize_text_field($_POST['apft_category_input']);

            apft_handle_file_upload($_FILES['apft_file']['tmp_name'], $post_status, $schedule_date, $schedule_type, $schedule_interval, $selected_category_id, $new_categories_input);
        }
        ?>
    </div>
    <script>
        document.getElementById('apft_post_status').addEventListener('change', function() {
            var value = this.value;
            var scheduleOptionsContainer = document.getElementById('schedule-options-container');
            var scheduleDateContainer = document.getElementById('schedule-date-container');
            if (value === 'future') {
                scheduleOptionsContainer.style.display = 'block';
                scheduleDateContainer.style.display = 'block';
            } else {
                scheduleOptionsContainer.style.display = 'none';
                scheduleDateContainer.style.display = 'none';
            }
        });

        document.getElementById('apft_schedule_type').addEventListener('change', function() {
            var unitSpan = document.getElementById('apft_schedule_interval_unit');
            switch (this.value) {
                case 'minute':
                    unitSpan.textContent = 'menit';
                    break;
                case 'hour':
                    unitSpan.textContent = 'jam';
                    break;
                case 'day':
                    unitSpan.textContent = 'hari';
                    break;
                default:
                    unitSpan.textContent = '';
            }
        });
    </script>
    <?php
}

function apft_handle_file_upload($file_path, $post_status, $schedule_date, $schedule_type, $schedule_interval, $selected_category_id, $new_categories_input) {
    if (file_exists($file_path)) {
        $file_content = file($file_path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

        // Process new categories input
        $new_categories = array_map('sanitize_text_field', explode(',', $new_categories_input));
        $new_category_ids = array();
        foreach ($new_categories as $category_name) {
            $category_name = trim($category_name);
            if (!empty($category_name)) {
                $term = term_exists($category_name, 'category');
                if ($term) {
                    $new_category_ids[] = $term['term_id'];
                } else {
                    $new_term = wp_insert_term($category_name, 'category');
                    if (!is_wp_error($new_term)) {
                        $new_category_ids[] = $new_term['term_id'];
                    }
                }
            }
        }

        // Combine selected and new categories
        $category_ids = array_filter(array_unique(array_merge([$selected_category_id], $new_category_ids)));

        $post_count = count($file_content);
        $intervals = array(
            'minute' => 60,       // Interval dalam detik
            'hour'   => 3600,     // Interval dalam detik
            'day'    => 86400     // Interval dalam detik
        );
        $interval = isset($intervals[$schedule_type]) ? $intervals[$schedule_type] * $schedule_interval : 86400;
        $current_time = $schedule_date ? strtotime($schedule_date) : time();
        
        foreach ($file_content as $index => $line) {
            if (!empty($line)) {
                $post_title = sanitize_text_field($line);
                $image_url = 'https://tse1.mm.bing.net/th?q=' . urlencode($post_title);
                $post_content = '<img class="img-fluid mx-auto d-block" src="' . esc_url($image_url) . '" />';

                $tags = array_map('sanitize_text_field', explode(' ', $post_title));

                $post_data = array(
                    'post_title'   => $post_title,
                    'post_content' => $post_content,
                    'post_status'  => $post_status,
                    'post_author'  => 1, // Ganti dengan ID pengguna Anda jika diperlukan
                    'post_category'=> $category_ids,
                    'tags_input'   => $tags,
                );

                if ($post_status === 'future') {
                    $post_data['post_date'] = date('Y-m-d H:i:s', $current_time);
                    $post_data['post_date_gmt'] = get_gmt_from_date($post_data['post_date']);
                    wp_insert_post($post_data);
                    $current_time += $interval; // Menambahkan interval dalam detik
                } else {
                    wp_insert_post($post_data);
                }
            }
        }
        echo '<div class="updated"><p>Post berhasil dibuat dari file .txt!</p></div>';
    } else {
        echo '<div class="error"><p>File tidak ditemukan.</p></div>';
    }
}
